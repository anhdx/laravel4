@extends('welcome')

@section('content')
	


	<button type="button" class="btn btn-success">button</button>
@endsection