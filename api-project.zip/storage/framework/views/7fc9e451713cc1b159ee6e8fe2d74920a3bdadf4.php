<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset=utf-8>
    <meta name=description content="None">
    <meta name=viewport content="width=device-width, initial-scale=1">
    <title></title>
     <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
     <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" type="text/javascript" charset="utf-8" async defer></script>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH C:\Users\Suchin\Desktop\api-project\resources\views/welcome.blade.php ENDPATH**/ ?>