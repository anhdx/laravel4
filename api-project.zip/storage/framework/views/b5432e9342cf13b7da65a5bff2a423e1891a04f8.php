<?php $__env->startSection('content'); ?>
	<button type="button" class="btn btn-success">button</button>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Suchin\Desktop\api-project\resources\views/api/index.blade.php ENDPATH**/ ?>